// Matheus Barbosa Silva - NUSP: 11221741
// Tarefa 1 - Deque Persistente

#include "dequeNode.hpp"

typedef struct {
	DequeNode* first;
	DequeNode* last;
} deque;
